package entities;

import java.util.ArrayList;

public class Trapezoid extends Shape{

    public Trapezoid(int x, int y) {
        super(x, y);

        points = new ArrayList<>(4);
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));

        update();
    }

    public Trapezoid(Shape shape) {
        this(shape, true);
    }

    public Trapezoid(Shape shape, boolean offset) {
        super(shape);

        this.leftUpperPoint = new Point(shape.leftUpperPoint, offset);
        this.rightUpperPoint = new Point(shape.rightUpperPoint, offset);
        this.leftLowerPoint = new Point(shape.leftLowerPoint, offset);
        this.rightLowerPoint = new Point(shape.rightLowerPoint, offset);

        points = new ArrayList<>(4);
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));

        update();
        connect();
    }

    @Override
    public void update() {
        points.get(0).set(new Point(
                (int) (leftUpperPoint.getX()*0.8 + rightUpperPoint.getX()*0.2),
                leftUpperPoint.getY()
        ));
        points.get(1).set(
                new Point((int) (leftUpperPoint.getX()*0.2 + rightUpperPoint.getX()*0.8),
                        leftUpperPoint.getY())
        );
        points.get(2).set(rightLowerPoint);
        points.get(3).set(leftLowerPoint);
    }
}
