package entities;

import java.util.ArrayList;

public class Triangle extends Shape{

    public Triangle(int x, int y) {
        super(x, y);

        points = new ArrayList<>(3);
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));

        update();
    }

    public Triangle(Shape shape) {
        this(shape, true);
    }

    public Triangle(Shape shape, boolean offset) {
        super(shape);

        this.leftUpperPoint = new Point(shape.leftUpperPoint, offset);
        this.rightUpperPoint = new Point(shape.rightUpperPoint, offset);
        this.leftLowerPoint = new Point(shape.leftLowerPoint, offset);
        this.rightLowerPoint = new Point(shape.rightLowerPoint, offset);

        points = new ArrayList<>(3);
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));

        update();
        connect();
    }

    @Override
    public void update() {
        points.get(0).set(new Point((leftUpperPoint.getX() + rightUpperPoint.getX())/2,
                leftUpperPoint.getY()));
        points.get(1).set(rightLowerPoint);
        points.get(2).set(leftLowerPoint);
    }
}
