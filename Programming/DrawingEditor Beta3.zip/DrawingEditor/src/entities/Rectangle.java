package entities;

import java.util.ArrayList;

public class Rectangle extends Shape{

    public Rectangle(int x, int y) {
        super(x, y);

        points = new ArrayList<>(4);
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));
        update();
    }

    public Rectangle(Shape shape) {
        this(shape, true);
    }

    public Rectangle(Shape shape, boolean offset) {
        super(shape);

        this.leftUpperPoint = new Point(shape.leftUpperPoint, offset);
        this.rightUpperPoint = new Point(shape.rightUpperPoint, offset);
        this.leftLowerPoint = new Point(shape.leftLowerPoint, offset);
        this.rightLowerPoint = new Point(shape.rightLowerPoint, offset);

        points = new ArrayList<>(4);
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));

        update();
        connect();
    }

    @Override
    public void update() {
        points.get(0).set(leftUpperPoint);
        points.get(1).set(rightUpperPoint);
        points.get(2).set(rightLowerPoint);
        points.get(3).set(leftLowerPoint);
    }
}
