package entities;

import java.util.ArrayList;

public class Line extends Shape{

    public Line(int x, int y) {
        super(x, y);

        points = new ArrayList<>(2);
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));

        update();
    }

    public Line(Shape shape) {
        this(shape, true);
    }

    public Line(Shape shape, boolean offset) {
        super(shape);

        this.leftUpperPoint = new Point(shape.leftUpperPoint, offset);
        this.rightUpperPoint = new Point(shape.rightUpperPoint, offset);
        this.leftLowerPoint = new Point(shape.leftLowerPoint, offset);
        this.rightLowerPoint = new Point(shape.rightLowerPoint, offset);

        points = new ArrayList<>(2);
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));

        update();
        connect();
    }

    @Override
    public void update() {
        points.get(0).set(startPoint);
        points.get(1).set(endPoint);
    }
}
