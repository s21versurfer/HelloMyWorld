package entities;

import java.awt.*;
import java.awt.geom.*;
import java.util.*;


public abstract class Shape implements ShapeInterface{
    ArrayList<Point> points;
    Point startPoint;
    Point endPoint;
    Point leftUpperPoint;
    Point rightUpperPoint;
    Point leftLowerPoint;
    Point rightLowerPoint;
    Path2D path = new Path2D.Double();
    BasicStroke strokeSize = new BasicStroke(2.0f);
    Color strokeColor = Color.BLACK;

    public Shape() {
        this(0, 0);
    }

    public Shape(int x, int y) {
        startPoint = new Point(x, y);
        endPoint = new Point(x, y);
        leftUpperPoint = new Point(x, y);
        rightUpperPoint = new Point(x, y);
        leftLowerPoint = new Point(x, y);
        rightLowerPoint = new Point(x, y);
    }

    public Shape(Shape shape) {
        this.startPoint = shape.startPoint;
        this.endPoint = shape.endPoint;
        this.strokeSize = shape.strokeSize;
        this.strokeColor = shape.strokeColor;
    }

    public void set(int endX, int endY) {
        endPoint = new Point(endX, endY);
        int x = startPoint.getX();
        int y = startPoint.getY();

        leftUpperPoint.set(
                Math.min(x, endX),
                Math.min(y, endY)
        );
        rightUpperPoint.set(
                Math.max(x, endX),
                Math.min(y, endY)
        );
        leftLowerPoint.set(
                Math.min(x, endX),
                Math.max(y, endY)
        );
        rightLowerPoint.set(
                Math.max(x, endX),
                Math.max(y, endY)
        );
    }

    public Color getStrokeColor() {
        return strokeColor;
    }

    public boolean contains(int x, int y) {
        return path.contains(x, y);
    }

    public boolean in(Rectangle2D rect) {
        return rect.contains(path.getBounds2D());
    }

    @Override
    public void change(Color color) {
        strokeColor = color;
    }

    @Override
    public void select(Graphics2D g2d) {
        for(Point point: points) point.draw(g2d);
    }

    @Override
    public void draw(Graphics2D g2d) {
        g2d.setStroke(strokeSize);
        g2d.setColor(strokeColor);
        g2d.draw(path);
    }

    @Override
    public void connect() {
        path.reset();
        if (points.size() > 1) {
            path.moveTo(points.get(0).getX(), points.get(0).getY());
            for (int i = 1; i < points.size(); i++)
                path.lineTo(points.get(i).getX(), points.get(i).getY());
            path.closePath();
        }
    }


    public Point getLeftUpperPoint() {
        return leftUpperPoint;
    }

    public Point getLeftLowerPoint() {
        return leftLowerPoint;
    }

    public Point getRightUpperPoint() {
        return rightUpperPoint;
    }

    public Point getRightLowerPoint() {
        return rightLowerPoint;
    }

    public Path2D getPath() {
        return path;
    }
}
