package entities;

import java.awt.*;
import java.util.*;

public class Ellipse extends Shape {
    public Ellipse(int x, int y) {
        super(x, y);

        points = new ArrayList<>(4);
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));

        update();
    }

    public Ellipse(Shape shape) {
        this(shape, true);
    }

    public Ellipse(Shape shape, boolean offset) {
        super(shape);

        this.leftUpperPoint = new Point(shape.leftUpperPoint, offset);
        this.rightUpperPoint = new Point(shape.rightUpperPoint, offset);
        this.leftLowerPoint = new Point(shape.leftLowerPoint, offset);
        this.rightLowerPoint = new Point(shape.rightLowerPoint, offset);

        points = new ArrayList<>(4);
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));
        points.add(new Point(0, 0));

        update();
    }

    @Override
    public void draw(Graphics2D g2d) {
        g2d.setStroke(strokeSize);
        g2d.setColor(strokeColor);
        g2d.drawOval(
                leftUpperPoint.getX(), leftUpperPoint.getY(),
                rightLowerPoint.getX() - leftUpperPoint.getX(),
                rightLowerPoint.getY() - leftUpperPoint.getY()
        );
    }

    @Override
    public void update() {
        points.get(0).set(leftUpperPoint);
        points.get(1).set(rightUpperPoint);
        points.get(2).set(rightLowerPoint);
        points.get(3).set(leftLowerPoint);
    }
}
