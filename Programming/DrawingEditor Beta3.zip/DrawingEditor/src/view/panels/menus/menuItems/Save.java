package view.panels.menus.menuItems;

import view.canvas.*;

import javax.imageio.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;

public class Save extends JMenuItem {
    public Save(MyCanvas canvas) {
        super("Save", new ImageIcon("images/save.png"));
        addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if(SaveAs.name != null) {
                    try {
                        ImageIO.write(SaveAs.getBufferedImageFromPanel(canvas), "png", new File(SaveAs.name));
                        System.out.println("saved Correctly");
                    } catch (IOException e1) {
                        System.out.println("Failed to save image");
                    }
                }
            }
        });
    }
}
