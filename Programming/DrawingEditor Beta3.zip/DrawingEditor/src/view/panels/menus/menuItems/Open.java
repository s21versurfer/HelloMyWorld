package view.panels.menus.menuItems;

import javax.swing.*;
import java.awt.event.*;
import java.io.*;

public class Open extends JMenuItem {
    public Open() {
        super("Open", new ImageIcon("images/file.png"));
        addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
                int result = fileChooser.showOpenDialog(null);

                if (result == JFileChooser.APPROVE_OPTION) {
                    // 여기서 파일을 열고 작업 수행
                    File selectedFile = fileChooser.getSelectedFile();
                    // TODO: 파일 열기 관련 작업 추가
                }
            }
        });
    }
}
