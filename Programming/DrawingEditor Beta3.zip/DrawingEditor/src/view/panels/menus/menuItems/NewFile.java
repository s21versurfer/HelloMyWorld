package view.panels.menus.menuItems;

import javax.swing.*;

public class NewFile extends JMenuItem{
    public NewFile() {
        super("New File", new ImageIcon("images/file.png"));
    }
}
