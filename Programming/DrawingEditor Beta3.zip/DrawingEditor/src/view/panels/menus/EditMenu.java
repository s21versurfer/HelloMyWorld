package view.panels.menus;

import javax.swing.*;

public class EditMenu extends JMenu {
    public EditMenu() {
        super("Edit");
    }
}
