package view.panels;

import view.canvas.*;

import javax.imageio.*;
import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.io.*;

public class CanvasBoard extends JPanel  {
    private MyCanvas canvas;

    public CanvasBoard(MyCanvas canvas) {
        this.canvas = canvas;
        setBackground(Color.WHITE);
        add(canvas);
    }

    public MyCanvas getCanvas() {
        return canvas;
    }

    public void saveAsImage(String filePath) {
        int width = getWidth();
        int height = getHeight();

        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        paint(g2d); // Canvas의 그림을 이미지로 그림

        try {
            File file = new File(filePath);
            ImageIO.write(image, "png", file); // 이미지를 파일로 저장 (png 형식)
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
