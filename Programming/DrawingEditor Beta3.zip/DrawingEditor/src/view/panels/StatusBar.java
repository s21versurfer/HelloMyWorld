package view.panels;

import view.canvas.*;
import view.panels.tools.*;

import javax.swing.*;
import java.awt.*;


public class StatusBar extends JPanel{
    MyCanvas canvas;
    CanvasLogger canvasLogger;

    public StatusBar(MyCanvas canvas, CanvasLogger canvasLogger, ZoomSlider zoomSlider) {
        setBackground(new Color(211, 211, 211));
        setLayout(new BorderLayout());

        this.canvasLogger = canvasLogger;
        this.canvas = canvas;

        setPreferredSize(new Dimension(710, 40));
        add(canvasLogger, BorderLayout.WEST);
        add(zoomSlider, BorderLayout.EAST);
    }
}
