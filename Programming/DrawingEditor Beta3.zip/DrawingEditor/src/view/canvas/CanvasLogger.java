package view.canvas;

import entities.*;

import javax.swing.*;
import java.util.*;


public class CanvasLogger extends JLabel {
    private String TEMP = "";
    private final Stack<String> MSG_STACK;
    private final Stack<ArrayList<Shape>> LOG_SHAPE_STACK;
    private final Stack<ArrayList<Group>> LOG_GROUP_STACK;
    private final Stack<ArrayList<Shape>> REDO_SHAPE_STACK;
    private final Stack<ArrayList<Group>> REDO_GROUP_STACK;
    private MyCanvas canvas;

    public CanvasLogger() {
        super();
        MSG_STACK = new Stack<>();
        LOG_SHAPE_STACK = new Stack<>();
        LOG_GROUP_STACK = new Stack<>();
        REDO_SHAPE_STACK = new Stack<>();
        REDO_GROUP_STACK = new Stack<>();

        setText("Status bar On");
        setSize(570, 20);
    }

    public String getString() {
        return "LOG_SHAPE_STACK: " + LOG_SHAPE_STACK.size() + "\nLOG_GROUP_STACK: " + LOG_GROUP_STACK.size() + "\nREDO_SHAPE_STACK: " + REDO_SHAPE_STACK.size() + "\nREDO_GROUP_STACK: " + REDO_GROUP_STACK.size();
    }

    public void setCanvas(MyCanvas canvas) {
        this.canvas = canvas;
    }

    public void logging(ArrayList<Shape> shapes, ArrayList<Group> groups) {
        setText(TEMP);
        ArrayList<Shape> tmp1 = new ArrayList<>();
        for(Shape shape: shapes) {
            String name = shape.getClass().getName();
            if (name.equals("entities.Rectangle")) {
                tmp1.add(new Rectangle(shape, false));
            } else if (name.equals("entities.Line")) {
                tmp1.add(new Line(shape, false));
            } else if (name.equals("entities.Triangle")) {
                tmp1.add(new Triangle(shape, false));
            } else if (name.equals("entities.Trapezoid")) {
                tmp1.add(new Trapezoid(shape, false));
            } else if (name.equals("entities.Pentagon")) {
                tmp1.add(new Pentagon(shape, false));
            } else if (name.equals("entities.Hexagon")) {
                tmp1.add(new Hexagon(shape, false));
            } else if (name.equals("entities.Ellipse")) {
                tmp1.add(new Ellipse(shape, false));
            } else if (name.equals("entities.Pencil")) {
                tmp1.add(new Pencil(shape, false));
            }
        }
        LOG_SHAPE_STACK.add(tmp1);

        ArrayList<Group> tmp2 = new ArrayList<>(groups);
        for(Group group: groups)
            tmp2.add(new Group(group, false));
        LOG_GROUP_STACK.add(tmp2);
        TEMP = "";
    }

    public void undo(ArrayList<Shape> shapes, ArrayList<Group> groups) {
        if(LOG_SHAPE_STACK.size() == 0) return;

        REDO_SHAPE_STACK.add(LOG_SHAPE_STACK.pop());
        REDO_GROUP_STACK.add(LOG_GROUP_STACK.pop());
        shapes.clear();
        groups.clear();
        if(LOG_SHAPE_STACK.size() == 0) return;

        shapes.addAll(LOG_SHAPE_STACK.get(LOG_SHAPE_STACK.size()-1));
        groups.addAll(LOG_GROUP_STACK.get(LOG_GROUP_STACK.size()-1));
    }

    public void redo(ArrayList<Shape> shapes, ArrayList<Group> groups) {
        if(REDO_SHAPE_STACK.size() == 0) return;

        LOG_SHAPE_STACK.add(REDO_SHAPE_STACK.pop());
        LOG_GROUP_STACK.add(REDO_GROUP_STACK.pop());
        shapes.clear();
        groups.clear();
        if(LOG_SHAPE_STACK.size() == 0) return;
        shapes.addAll(LOG_SHAPE_STACK.get(LOG_SHAPE_STACK.size()-1));
        groups.addAll(LOG_GROUP_STACK.get(LOG_GROUP_STACK.size()-1));
    }

    public void append(String logMsg) {
        TEMP += "\t" + logMsg;
    }

    public void append(int i) {
        TEMP += "\t" + String.format("%d", i);
    }

    public void update() {
        setText(MSG_STACK.get(MSG_STACK.size()-1));
    }
}

